<?php
/*
This file is part of miniBB. miniBB is free discussion forums/message board software, without any warranty. See COPYING file for more details. Copyright (C) 2004-2005 Paul Puzyrev, Sergei Larionov. www.minibb.net
*/

$clForums=array();
$clForumsUsers[]=array();
$roForums=array();
$poForums=array();
$regUsrForums=array();

$userRanks=array();

$mods=array();

//$lastOut=array(); 
//$themeDesc=array(); 
//$redthread=array();
?>